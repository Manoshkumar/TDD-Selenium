from selenium import webdriver
from TestDesign.ExcelUtils import readdata
from TestDesign.ExcelUtils import writedata
from TestDesign.ExcelUtils import getRowCount
from selenium.common.exceptions import NoSuchElementException
from TestDesign.ExcelUtils import getColumnCount
import time

driver = webdriver.Chrome(executable_path='C:/Users/Nithin/PycharmProjects/Booking/Drivers/chromedriver.exe')
driver.implicitly_wait(1)
driver.get("https://opensource-demo.orangehrmlive.com/")
driver.maximize_window()

path="C:/Users/Nithin/PycharmProjects/TDD/TestDesign/TestDesign_data.xlsx"
rows=getRowCount(path,'Sheet1')
for r in range(2,rows+1):
    username = readdata(path,"Sheet1",r,3)
    password = readdata(path,"Sheet1",r,4)
    driver.find_element_by_id("txtUsername").clear()
    driver.find_element_by_id("txtUsername").send_keys(username)
    driver.find_element_by_id("txtPassword").clear()
    driver.find_element_by_id("txtPassword").send_keys(password)
    driver.find_element_by_id("btnLogin").click()
    time.sleep(2)
    try:
        element = driver.find_element_by_id("welcome")
        writedata(path,"Sheet1",r,5,"Test Passed")
        driver.find_element_by_id("welcome").click()
        driver.find_element_by_partial_link_text("Logout").click()
    except NoSuchElementException:
        writedata(path,"Sheet1",r,5,"Test Failed")
driver.close()









